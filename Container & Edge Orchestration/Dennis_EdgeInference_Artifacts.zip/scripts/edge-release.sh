#!/usr/bin/env bash
# edge-release.sh — Git-driven ring rollout / rollback for IoT Edge 1.6 devices.
# Invoked ONLY by the GitHub Actions workflow (.github/workflows/edge-release.yml) on
# merges to the 'release' branch or by operator "Run workflow" buttons. Operators
# never run az or kubectl themselves. Requires: az CLI + azure-iot extension, jq, envsubst.
#
# Model: one BASE deployment (priority 10) holds the last fleet-wide known-good release.
#        Each new release is ONE LAYERED deployment (priority 100+N) whose target
#        condition is widened ring by ring. Rollback = delete the layer -> every targeted
#        device falls back to the base (known-good) within its next twin sync.
set -euo pipefail

HUB="${IOT_HUB_NAME:?}"                 # e.g. logistics-edge-hub
FLEET_COND="tags.fleet='damage-detect'"
MANIFEST_DIR="${MANIFEST_DIR:-iot-edge-manifest}"
OUT_DIR="${OUT_DIR:-.rendered}"
mkdir -p "$OUT_DIR"

# Only these placeholders are substituted. An unrestricted envsubst would also blank out
# $edgeAgent, $edgeHub and $upstream, producing a broken manifest.
SUBST_VARS='${ACR_LOGIN_SERVER} ${ACR_PULL_TOKEN_NAME} ${ACR_PULL_TOKEN_PASSWORD} ${FRAME_CAPTURE_DIGEST} ${INFERENCE_DIGEST} ${INFERENCE_TAG} ${INFERENCE_MODULE_VERSION} ${MODEL_SHA256}'

# Render template: substitute placeholders and stringify createOptions (what IoT Hub expects).
render() {  # $1 = template file, $2 = output file
  envsubst "$SUBST_VARS" < "$1" \
  | jq 'del(."$schema-template")
        | walk(if type=="object" and has("createOptions") and (.createOptions|type)=="object"
               then .createOptions |= tojson else . end)' > "$2"
  # Guardrail: refuse anything not pinned to the IoT Edge 1.6 LTS line
  if grep -Eq 'azureiotedge-(agent|hub):1\.[0-5]' "$2"; then
    echo "ERROR: manifest references an IoT Edge runtime older than 1.6 LTS" >&2; exit 2
  fi
}

ring_condition() {  # cumulative rings: ring1 => ring0+ring1
  case "$1" in
    ring0) echo "$FLEET_COND AND tags.ring IN ['ring0']" ;;
    ring1) echo "$FLEET_COND AND tags.ring IN ['ring0','ring1']" ;;
    ring2) echo "$FLEET_COND AND tags.ring IN ['ring0','ring1','ring2']" ;;
    ring3) echo "$FLEET_COND" ;;
    *) echo "unknown ring $1" >&2; exit 2 ;;
  esac
}

deploy_id() { echo "inf-${INFERENCE_TAG//./-}" | tr '[:upper:]' '[:lower:]'; }

metrics_json() {
  cat <<EOF
{"queries":{
 "runningRelease":"SELECT deviceId FROM devices.modules WHERE moduleId='damage-inference' AND properties.reported.release.version='${INFERENCE_TAG}'",
 "latencySloBreach":"SELECT deviceId FROM devices.modules WHERE moduleId='damage-inference' AND properties.reported.latencyP95Ms > 200"
}}
EOF
}

cmd="${1:?usage: edge-release.sh base|target|rollback|status [ring]}"
case "$cmd" in
  base)      # promote a fully soaked release to the fleet floor (priority 10)
    render "$MANIFEST_DIR/deployment.template.json" "$OUT_DIR/base.json"
    az iot edge deployment create -n "$HUB" -d "base-${INFERENCE_TAG//./-}" \
      --content "$OUT_DIR/base.json" --target-condition "$FLEET_COND" --priority 10 ;;
  target)    # create the release layer (ring0) or widen/narrow it to the given ring.
             # Widening only runs after ring-gate.kql returns zero failing sites (workflow step).
    ring="${2:?ring}"
    if az iot edge deployment show -n "$HUB" -d "$(deploy_id)" >/dev/null 2>&1; then
      az iot edge deployment update -n "$HUB" -d "$(deploy_id)" \
        --set targetCondition="$(ring_condition "$ring")"
    else
      render "$MANIFEST_DIR/inference.layer.template.json" "$OUT_DIR/layer.json"
      az iot edge deployment create -n "$HUB" -d "$(deploy_id)" --layered \
        --content "$OUT_DIR/layer.json" --target-condition "$(ring_condition "$ring")" \
        --priority "$((100 + ${RELEASE_SEQ:?}))" --metrics "$(metrics_json)"
    fi ;;
  rollback)  # delete the layer: devices revert to the base (known-good) release
    az iot edge deployment delete -n "$HUB" -d "$(deploy_id)" ;;
  status)
    for m in targetedCount appliedCount reportedSuccessfulCount reportedFailedCount; do
      echo "== $m"; az iot edge deployment show-metric -n "$HUB" -d "$(deploy_id)" \
        -m "$m" --metric-type system -o table; done ;;
  *) echo "unknown command $cmd" >&2; exit 2 ;;
esac
