SCENARIO DATA PACKAGE — LC1 Project Module
Hybrid Architecture Review: Multicloud AI Fraud Detection System
Prepared for: Platform Architect Role-Play Assessment
Last Updated: Q2 2026

=============================================================
CONTENTS OF THIS PACKAGE
=============================================================

1. Incident_Report_1_20260312.txt   — Pilot Outage 1 (March 12, 2026)
2. Incident_Report_2_20260401.txt   — Pilot Outage 2 (April 1, 2026)
3. Incident_Report_3_20260418.txt   — Pilot Outage 3 (April 18, 2026)
4. GPU_Cost_Snapshot_Q1_2026.csv    — GPU spend vs. budget (Jan–Mar 2026)
5. Policy_Configuration_Status.txt — Azure Policy compliance gaps (as of Apr 20 2026)
6. README.txt                       — This file

=============================================================
HOW TO USE THIS PACKAGE
=============================================================

Step 1 — Read all three incident reports.
  Note: each report is intentionally partial. Root causes are not fully
  confirmed. Your WAF review should use the available evidence only —
  do not invent additional facts.

Step 2 — Review the GPU cost snapshot.
  The CSV maps spend by workload type and instance class. Use the
  budget vs. actual columns to ground your Cost Optimization finding.

Step 3 — Review the policy configuration status report.
  Six policy gaps are listed. Not all require immediate remediation.
  Your job is to prioritize the ones with highest risk, not fix all six.

Step 4 — Cross-reference findings to WAF pillars:
  Reliability        → Incident Reports 1 and 3
  Security           → Policy Configuration Status (Gaps 1–4)
  Cost Optimization  → GPU Cost Snapshot
  Operational Excel. → Incident Report 2 + Policy Gap 6
  Performance Effic. → GPU Cost Snapshot (instance sizing section)

=============================================================
SCENARIO CONSTRAINTS (do not ignore in your review)
=============================================================

- Q3 launch is fixed. Fixes must not require >4 weeks of platform freeze.
- Platform team has 4 engineers. Significant items must be sequenced.
- AWS DR environment is outside Azure Policy scope. Flag but note limitation.
- Legal sign-off on Data Sovereignty (Gap 5) is pending. Do not treat as
  resolved — treat as an open risk requiring escalation in your roadmap.

=============================================================
DATA NOTICE
=============================================================

All figures, timestamps, employee names, and transaction counts in this
package are fictional and created for educational purposes only.
No real customer, financial, or personal data is included.
