#!/usr/bin/env bash
# [PLATFORM] one-time bootstrap of the Flux v2 GitOps extension (microsoft.flux) on the
# central AKS cluster. After this, every change ships by merging to the 'release' branch;
# nobody applies manifests with kubectl.
set -euo pipefail
RG=rg-edge-central
AKS=aks-edge-central

az k8s-extension create -g "$RG" -c "$AKS" -t managedClusters \
  --name flux --extension-type microsoft.flux

az k8s-configuration flux create -g "$RG" -c "$AKS" -t managedClusters \
  --name edge-inference --namespace flux-system --scope cluster \
  --url https://github.com/logistics-platform/edge-inference-gitops.git --branch release \
  --kustomization name=flagger  path=./clusters/prod/flagger        prune=true \
  --kustomization name=apps     path=./clusters/prod/edge-inference prune=true depends_on=["flagger"]

# Verify (platform only)
az k8s-configuration flux show -g "$RG" -c "$AKS" -t managedClusters -n edge-inference \
  --query "{compliance:complianceState, statuses:statuses[].{kind:kind,name:name,state:complianceState}}"
