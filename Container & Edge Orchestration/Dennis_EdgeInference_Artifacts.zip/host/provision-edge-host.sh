#!/usr/bin/env bash
# [PLATFORM] Golden-image provisioning for a site edge PC (run once at imaging time).
# Host OS: Ubuntu Server 22.04 LTS (IoT Edge 1.6 Tier 1, AMD64). Azure Linux 3.0 is NOT
# used as the host OS: it is not listed on the IoT Edge 1.6 supported-platforms page.
# Runtime: Azure IoT Edge 1.6 LTS, pinned. IoT Edge 1.5 LTS (EoS 10 Nov 2026) is never installed.
set -euo pipefail
. /etc/os-release
[ "$ID" = "ubuntu" ] && [ "$VERSION_ID" = "22.04" ] || { echo "Ubuntu 22.04 required"; exit 1; }

# 1. Microsoft package feed + container engine
curl -fsSL https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -o /tmp/ms.deb
dpkg -i /tmp/ms.deb && apt-get update
apt-get install -y moby-engine

# 2. Pin IoT Edge to the 1.6 LTS line and hold it (unattended-upgrades cannot move it)
cat >/etc/apt/preferences.d/aziot-edge-1.6 <<'EOF'
Package: aziot-edge aziot-identity-service
Pin: version 1.6.*
Pin-Priority: 1001
EOF
apt-get update && apt-get install -y aziot-edge
apt-mark hold aziot-edge aziot-identity-service

# 3. Container log rotation (protects the 32 GB eMMC)
cat >/etc/docker/daemon.json <<'EOF'
{ "log-driver": "local", "log-opts": { "max-size": "10m", "max-file": "3" } }
EOF
systemctl restart docker

# 4. Dedicated 8 GB buffer volume (separate filesystem: a full buffer can never fill the OS)
grep -q 'LABEL=edge-buffer' /etc/fstab || \
  echo 'LABEL=edge-buffer /srv/edge-buffer ext4 defaults,noatime,nodev,nosuid 0 2' >> /etc/fstab
mkdir -p /srv/edge-buffer && mount -a
install -d -o 1000  -g 1000  -m 700 /srv/edge-buffer/edgehub   # edgeHub runs as UID 1000
install -d -o 65532 -g 65532 -m 700 /srv/edge-buffer/spool     # frame-capture + damage-inference
install -d -m 700 /var/lib/edge-agent

# 5. Bootstrap config: DPS + X.509; bootstrap edgeAgent image pinned to 1.6.0 as well
cat >/etc/aziot/config.toml <<EOF
[provisioning]
source = "dps"
global_endpoint = "https://global.azure-devices-provisioning.net"
id_scope = "${DPS_ID_SCOPE:?}"
[provisioning.attestation]
method = "x509"
registration_id = "$(hostname)"
identity_cert = "file:///etc/aziot/certs/device-identity.pem"
identity_pk = "file:///etc/aziot/private/device-identity.key.pem"

[agent]
name = "edgeAgent"
type = "docker"
[agent.config]
image = "mcr.microsoft.com/azureiotedge-agent:1.6.0"
EOF
iotedge config apply
iotedge version | grep -q '^iotedge 1\.6\.' || { echo "IoT Edge 1.6 not active"; exit 1; }
iotedge check --verbose || true   # review warnings during imaging
