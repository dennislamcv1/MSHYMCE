# Operational Runbook — Edge Inference Pipeline

Audience: distribution-center operations staff (no raw kubectl). Platform-team-only steps are marked **[PLATFORM]**.
Operator tools: the **Edge Ops dashboard** (Entra ID sign-in, role *SiteOperator*) and the **GitHub web UI** (Revert button, "Run workflow" button). Every dashboard action calls a built-in IoT Edge 1.6 `$edgeAgent` direct method through IoT Hub; no shell, SSH or cluster access is needed.

## SLA / Target Reference

| Metric | Target |
|---|---|
| Rollout success rate (fleet-wide) | ≥ 98 % of targeted devices report the new release within 30 min of being online, without manual action (≤ 1 of 50 sites needs help) |
| Sync window after reconnection | ≤ 15 min to fully drain a p99 (4 h) outage backlog; ≤ 60 min for the 72 h ceiling (MPLS) |
| MTTR — single-site incident | ≤ 30 minutes |
| MTTR — fleet-wide incident | ≤ 2 hours |
| Max concurrent site incidents before escalation | 3 sites (≥ 3 at once = fleet incident, page Platform immediately) |
| Inference latency p95 threshold | < 200 ms |

## 1. Health Check (run first, every time)

- [ ] Open the Edge Ops dashboard → **Site status** panel. Note whether the site is *Online* or *Offline (since hh:mm)*.
- [ ] Confirm inference latency p95 < 200 ms. If above, go to §3.
- [ ] Confirm buffer utilization < 80 % of the 5 GB buffer budget (< 4 GB). If above, go to §3. A normal 72 h outage only reaches ~24 %.
- [ ] Confirm last successful sync < 10 minutes ago (Online sites). Offline sites: < 4 h = normal; 4–72 h = inform Site Lead; > 72 h = escalate **[PLATFORM]**.
- [ ] Confirm camera capture success ≥ 99 % and all modules show *running* on the **Modules** tile.

## 2. Trigger a Rollout

- [ ] Confirm the change is merged to the GitOps `release` branch (central orchestrator: Flux v2 AKS extension reconciles automatically; edge sites: the `edge-release` workflow applies the IoT Hub deployment — never push manually to the cluster or devices).
- [ ] Edge widening (ring0 → ring1 → ring2 → ring3) happens by merging the PR that changes `RING` in `releases/edge/<version>.env`. Platform approves ring2/ring3; the workflow blocks widening if the ring gate fails.
- [ ] Watch status on the dashboard: **Canary** panel (Flagger analysis, central) and **Ring rollout** panel (targeted / applied / successful / failed devices, edge).
- [ ] Verify success criteria:
  - Central: Flagger reaches 50 % and promotes; error rate < 1 % and p99 latency < 500 ms on every 1-minute check.
  - Edge (per ring, after soak): p95 < 200 ms, inference errors < 0.5 %, 0 unexpected module restarts, sync lag < 10 min while online, damage-detection rate within ±25 % of the site's 7-day baseline, successful = targeted for online devices.
- [ ] Freeze (week 6 onward): only emergency fixes, compressed soak (4 h / 4 h / 2 h), during the lowest-volume shift.

## 3. Troubleshoot Common Failures

| Symptom | Likely cause | Operator action |
|---|---|---|
| Latency p95 above threshold | Device resource contention (backlog after restart, log storm) | Dashboard → Site → **Restart inference module** (RestartModule). Re-check in 10 min. After 2 restarts → Site Lead / **[PLATFORM]** |
| Buffer near capacity (> 80 %) | Upstream rejecting while link is up (IoT Hub quota, certificate/auth) or trigger storm creating extra events; a plain 72 h outage reaches only ~24 % | If site Online and not draining → escalate **[PLATFORM]**. If event rate abnormal → **Restart frame-capture** |
| Sync not resuming after reconnect | Device certificate/auth failure, IoT Hub daily quota exhausted, route misconfiguration in last release | Dashboard → **Ping edgeAgent**. No reply or lag still rising after 15 min → **[PLATFORM]**. Started right after a release → rollback (§4) |
| Event count mismatch / duplicate-reject spike | Idempotency-key collision (e.g. clock reset) — events wrongly treated as duplicates | Escalate **[PLATFORM]** (reconciliation). No operator action |
| Camera capture failures | Camera power/PoE, cable, camera credentials | Check camera power and link LEDs; Dashboard → **Restart frame-capture** |
| Rollout stuck in Canary analysis (central) | Metric threshold breach | Automatic rollback triggers; confirm on Canary panel, no operator action needed |
| Edge ring gate failed | Ring metric breach on soaked sites | Workflow removes the release layer automatically; confirm sites show the known-good version on Ring rollout panel |
| Device offline after power event | Host boot, disk | Power-cycle the edge PC per site procedure; runtime starts offline-capable. Not back in 15 min → **[PLATFORM]** |

## 4. Rollback

- [ ] Identify last known-good release tag in GitOps release history (dashboard **Releases** panel shows the base version per site).
- [ ] Central: open the merged PR in GitHub → **Revert** → merge. Flux reconciles within 5 min — operator-facing action, no kubectl.
- [ ] Edge: **Revert** the release PR (narrows the ring, or removes the release so every device falls back to the base version). Emergency: GitHub → Actions → `edge-release` → **Run workflow → rollback** (platform approval).
- [ ] Confirm health check (§1) passes post-rollback and the Ring rollout panel shows affected devices on the known-good version.
- [ ] If rollback does not resolve within 20 minutes, escalate **[PLATFORM]**.

## 5. Escalation Path

1. Operator → Site Lead (immediate, if health check fails twice in a row)
2. Site Lead → Platform Team on-call (if §3/§4 doesn't resolve within MTTR target, or ≥ 3 sites affected at once)
3. Platform Team → raw kubectl / cluster-level diagnostics (platform-only, never operator-facing)

## 6. [PLATFORM] Diagnostic Commands (not for operator use)

```bash
HUB=logistics-edge-hub; DEV=dc-017-edge01
# Edge device state (no SSH needed) — runtime must report 1.6.x
az iot hub module-twin show -n $HUB -d $DEV -m '$edgeAgent' \
  --query "properties.reported.{runtime:systemModules.edgeAgent.settings.image, modules:modules}"
az iot hub invoke-module-method -n $HUB -d $DEV -m '$edgeAgent' --mn GetModuleLogs \
  --mp '{"schemaVersion":"1.0","items":[{"id":"damage-inference","filter":{"tail":200}}],"encoding":"none","contentType":"text"}'
az iot hub invoke-module-method -n $HUB -d $DEV -m '$edgeAgent' --mn RestartModule \
  --mp '{"schemaVersion":"1.0","id":"edgeHub"}'
az iot edge deployment show-metric -n $HUB -d inf-2-0-0-litert-int8 -m reportedFailedCount --metric-type system
az iot hub monitor-events -n $HUB -d $DEV --properties anno sys --timeout 60
# Central AKS (platform only)
kubectl -n edge-inference get canary,deploy,pods
kubectl get gitrepositories,kustomizations,helmreleases -A
az k8s-configuration flux show -g rg-edge-central -c aks-edge-central -t managedClusters -n edge-inference
# Never print device connection strings; devices use X.509 via DPS.
```
